class Account: #base account class to define common attributes and methods between savings and checking
    def __init__(self, startingBalance):
        self.__balance = startingBalance

    def __str__(self):
        return 'Account:\n   Current Balance: ${}'.format(self.__balance)

    def getBalance(self): #return acc balance
        return self.__balance

    def withdraw(self, amount): #base withdraw (no fees/added features)
        if self.__balance >= amount:
            newBalance = self.__balance - amount
            self.__balance = newBalance
            return newBalance
        else:
            print("Not enough funds, Current Balance: " + str(self.__balance))

    def deposit(self, amount): #customer can deposit (increase acc balance)
        balance = self.__balance
        self.__balance = balance+amount
        print('You have deposited ${}'.format(amount))
        print('Current Balance: ${}'.format(self.__balance))
        return self.__balance

    __repr__ = __str__
