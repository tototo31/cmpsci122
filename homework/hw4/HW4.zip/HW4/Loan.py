class Loan: #used for customer loans
	def __init__(self, amount):
		self.__amount = amount
		self.__dues = amount

	def __str__(self):
		return 'Loan:\n   Amount: ${} | Remaining Dues: ${}'.format(self.__amount, self.__dues)

	def pay(self, payment): #customer can pay off loan (in mulitple payments)
			self.__dues -= payment

	def getDues(self): #returns remaining dues
		return self.__dues


