from Customer import *
import random

class Teller(Person):
    def __init__(self, name, birthdate, phone, address, salary=4000):
        Person.__init__(self, name, birthdate, phone, address) #uses the parent class (person)
        self.__salary = salary
        self.id = self.__createID() 
        

    def __str__(self):
        return 'Employee:\n   Role: Teller | Name: {} | Salary: ${}/mo | Employee ID: {}\n'.format(self.name, self.__salary, self.id)

    def __createID(self): #generates a random 3 digit id number
        return random.randint(100,999)

    def getInfo(self):
        print('Employee:\n'\
            '   Role: Teller\n   Name: {}\n   Salary: ${}/mo\n   Employee ID: {}\n'\
            '   D.O.B: {}\n   Address: {}\n   Phone #: {}'.format(self.name, self.__salary, self.id, self._Person__birthdate, self._Person__address, self._Person__phone))

    def getCustInfo(self, Customer): #teller has access to limited customer info
        print('Customer:\n   Name: {}\n   Address: {}\n   Phone #: {}'.format(Customer.name, Customer._Person__address, Customer._Person__phone))

    def withdrawSavings(self, Customer, amount): #teller can withdraw for a customer
        Customer.savings.withdraw(amount)  

    def depositSavings(self, Customer, amount): #teller can deposit for a customer
        Customer.savings.deposit(amount)

    def withdrawChecking(self, Customer, amount): #teller can withdraw for a customer
        Customer.checking.withdraw(amount)  

    def depositChecking(self, Customer, amount): #teller can deposit for a customer
        Customer.checking.deposit(amount)

    __repr__ = __str__
#--------------------------------------------------------------------------------------------------------------------------
class Manager(Person):
    def __init__(self, name, birthdate, phone, address, salary=7500):
        Person.__init__(self, name, birthdate, phone, address) #uses the parent class (person)
        self.__salary = salary
        self.id = self.__createID()

    def __str__(self):
        return 'Employee:\n   Role: Manager | Name: {} | Salary: ${}/mo | Employee ID: {}'.format(self.name, self.__salary, self.id)

    def __createID(self): #generates a random 3 digit id number
        return random.randint(100,999)

    def getInfo(self):
        print('Employee:\n'\
             '   Role: Manager\n   Name: {}\n   Salary: ${}/mo\n   Employee ID: {}\n'\
             '   D.O.B: {}\n   Address: {}\n   Phone #: {}'.format(self.name, self.__salary, self.id, self._Person__birthdate, self._Person__address, self._Person__phone))

    def getCustInfo(self, Customer): #manager has detailed customer info
        print('Customer:\n   Name: {}\n   Address: {}\n   Phone #: {}\n   D.O.B: {}\n   SSN: {}'.format(Customer.name, Customer._Person__address, Customer._Person__phone, Customer._Person__birthdate, Customer._Customer__social))

    def viewAccounts(self, Customer): #lists all active customer accounts
        acc = Customer.name + ':'
        if hasattr(Customer,'savings'): #makes sure the account exists
            acc += str(Customer.savings)
        if hasattr(Customer,'checking'):
            acc += str(Customer.checking)

        print(acc)

    def delSavings(self, Customer): #deletes a customer's savings acc (if they have one)
        if hasattr(Customer, 'savings'):
            del zach.savings
            print(Customer.name + "'s savings account has been deleted.")
        else:
            print(Customer.name + ' does not have an active savings account!')

    def delChecking(self, Customer): #deletes a customer's checking acc (if they have one)
        if hasattr(Customer, 'checking'):
            del zach.savings
            print(Customer.name + "'s checking account has been deleted.")
        else:
            print(Customer.name + ' does not have an active checking account!')

    def openSavings(self, Customer, startBalance): #create savings acc for a customer
        Customer.openSavings(startBalance)

    def openChecking(self, Customer, startBalance): #create checking acc for a customer
        Customer.openChecking(startBalance)

    def giveLoan(self, Customer, amount): #rejects loan requests from minors
        if Customer.isMinor:
            print('Request Denied.')
        else:
            Customer.loan = Loan(amount)
            print('Request Approved')

    def changeFee(self, Customer, newFee): #change a customer's withdraw fee
        if hasattr(Customer, 'checking'):
            Customer.checking._Checking__withdrawFee = newFee
            print('Manager ({}) changed the withdraw fee to ${}'.format(self.name, newFee))

    def changeIR(self, Customer, newRate): #change a customer's interest rate
        if hasattr(Customer, 'savings'):
            Customer.savings._Savings__interestRate = newRate
            print('Manager ({}) changed the interest rate to {}%'.format(self.name, newRate))

    __repr__ = __str__
