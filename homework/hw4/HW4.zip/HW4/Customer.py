from Person import *
from Checking import *
from Savings import *
from Loan import *

import random

class Customer(Person):
    def __init__(self, name, birthdate, phone, address):
        Person.__init__(self, name, birthdate, phone, address) #uses the parent class (person)
        self.__social = random.randint(100000000, 999999999) #create random 10 digit ssn
        if self.getAge() >= 18: #determines whether or not a customer is a minor using the person class' getAge() method
            self.isMinor = False
        else:
            self.isMinor = True
        
    def __str__(self):
        return 'Customer:\n   Name: {} | Age: {}'.format(self.name, self.getAge())

    def getInfo(self):
        print('Customer:\n   Name: {}\n   D.O.B: {}\n   Address: {}\n   Phone #: {}'.format(self.name, self._Person__birthdate, self._Person__address, self._Person__phone))

    def openSavings(self, startBalance=0):
        if hasattr(self, 'savings'): #checks if customer already has a savings account
            print('This customer already has an active savings account!')
        else:
            self.savings = Savings(startBalance) #creates a savings acc for the customer
            print('{} has opened a savings account.'.format(self.name))
            print(self.savings)

    def openChecking(self, startBalance=0):
        if hasattr(self, 'checking'): #checks if customer already has a checking account
            print('This customer already has an active checking account!')       
        else:
            self.checking = Checking(startBalance) #creates a checking acc for the customer
            print('{} has opened a checking account.'.format(self.name))
            print(self.checking)

    def requestLoan(self, amount, Manager):
        print('You have requested a loan for ${}'.format(amount))
        Manager.giveLoan(self, amount) #manager determines if the loan is requested

    def payLoan(self, payment):
        self.loan.pay(payment) #uses the Loan class method (multiple ways to make payments)
        print('You paid ${}'.format(payment))
        print('Remaining Payment Due: ${}'.format(self.loan.getDues()))

    __repr__ = __str__





 











    
        
