from Account import *

class Savings(Account):
    
    def __init__(self, startingBalance):
        Account.__init__(self, startingBalance) #uses parent class (account)
        if startingBalance < 100: 
            self.__interestRate = 0 #penalty if the start balance is below minimum (no interest)
        else:
            self.__interestRate = .02 #intrest rate (can be changed by manager)
        self.__minBalance = 100

    def __str__(self):
        return 'Savings Account:\n   Current Balance: ${} | Interest Rate: {}%\n'.format(self._Account__balance, self.__interestRate)

    def withdraw(self, amount):
        confirm = input("Current Balance: ${} | Would you like to withdraw ${}?(Y/N)".format(self._Account__balance, amount)) #customer confirms withdraw
        if confirm == "Y" or confirm == "y":
            if self._Account__balance >= (amount + self.__minBalance): #can only withdraw if remaing balance will be above minimum
                newBalance = self._Account__balance - (amount)
                self._Account__balance = newBalance
                return newBalance
            else:
                return "Not enough funds! Current Balance: ${} | Minimum Balance Allowed: ${}".format(self._Account__balance, self.__minBalance)
        elif confirm == "N" or confirm == "n":
            return "Request Cancelled"
        else:
            self.withdraw(self, amount)

    __repr__ = __str__
 
